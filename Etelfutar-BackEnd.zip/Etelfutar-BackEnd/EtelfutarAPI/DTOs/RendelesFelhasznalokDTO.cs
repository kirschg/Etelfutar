﻿using EtelfutarAPI.Models;

namespace EtelfutarAPI.DTOs
{
    public class RendelesFelhasznalokDTO
    {
        public RendelesFelhasznalokDTO(Felhasznalok felhasznalok)
        { 
            Id = felhasznalok.Id;
            FelhasznaloNev = felhasznalok.FelhasznaloNev;
            Email = felhasznalok.Email;
            Varos = new FelhasznalokVarosDTO(felhasznalok.Varos);
            Lakcim = felhasznalok.Lakcim;
            Hash = felhasznalok.Hash;
            Salt = felhasznalok.Salt;
            Jogosultsag = felhasznalok.Jogosultsag;
        }

        public int Id { get; set; }
        public string FelhasznaloNev { get; set; }
        public string Email { get; set; }
        public FelhasznalokVarosDTO Varos { get; set; }
        public string Lakcim { get; set; }
        public string Hash { get; set; }
        public string Salt { get; set; }
        public int Jogosultsag { get; set; }
    }
}
