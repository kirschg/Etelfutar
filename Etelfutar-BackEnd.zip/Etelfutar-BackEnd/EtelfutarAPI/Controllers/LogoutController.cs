﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace VizsgaremekAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogoutController : ControllerBase
    {
        [HttpPost("{uId}")]
        public IActionResult Logout(string uId)
        {
            if(Program.LoggedInUsers.ContainsKey(uId))
            {
                Program.LoggedInUsers.Remove(uId);
                return Ok("Sikeres kijelentkezés!");
            }
            else
            {
                return NotFound("Nem található felhasználó ezzel a tokennel!");
            }
        }

    }
}
